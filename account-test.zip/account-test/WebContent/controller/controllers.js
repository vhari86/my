'use strict';

accountApp.controller('loginController', function($scope,$modal, $log) {
	// create a message to display in our view
	$scope.some = 'Everyone come and see how good I look!';
	
	$scope.loginusers = [{loginId: 1,username: 'arjun anappara'},{loginId: 2,username: 'yogesh rustagi'}];
	
	 $scope.addLoginUser = function () {

		 $log.info('Modal dismissed at: ' + new Date());		    
 modalInstance = $modal.open()({
		      templateUrl: 'pages/about.html',
		      controller: ModalInstanceCtrl,
		      resolve: {
		        items: function () {
		          return $scope.items;
		        }
		      }
		    });
		    }
	
});

accountApp.controller('ModalInstanceCtrl', function($scope,$modal, $log) {

	 $log.info('Modal lll at: ' + new Date());
	
});