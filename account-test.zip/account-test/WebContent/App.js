var newConfig = function($routeProvider) { 
	$routeProvider
		.when('/', {
			 templateUrl: 'view/login.html'
		})
		.when('/view2', {
			 templateUrl: 'view/view2.html'
		})
		.otherwise({redirectTo : 'view1'})
	;
};

var App = angular.module('Appss',[]).config(newConfig);

App.controller('mainController', function($scope) {

	// create a message to display in our view
	$scope.message = 'Everyone come and see how good I look!';
});
