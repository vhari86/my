App.directive('gbNoteList', function() { 
	
});
